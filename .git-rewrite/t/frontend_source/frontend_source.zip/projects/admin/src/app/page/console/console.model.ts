export class Console {

    message: string;

    constructor() {
    }
}

