export class ActiveActionModel {
    hw_action_id: number;
    name: string;
    hw_module_id: string;
    value: any;
}
