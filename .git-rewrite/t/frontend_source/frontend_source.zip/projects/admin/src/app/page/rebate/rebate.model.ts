export class Rebate {
    id: number;
    value: number;
    rebate_is_fixed: boolean;
    description: string;
    active: boolean;
    deleted: boolean;
    
}
