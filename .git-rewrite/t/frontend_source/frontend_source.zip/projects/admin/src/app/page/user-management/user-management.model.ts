export class UserManagement {
    email: string;
    password: string;
    timezone: string;
    timezone_id: number;
    map_pool_time: number;
    account_type_id: number;
    language_id;
    fullname: string;
    locked: boolean;
    active: boolean;
}
