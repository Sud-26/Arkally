export const loginConfig = {
    title: 'app.title',
    avatar: {
        icon: 'assets:logo',
        background: '#5D576B'
    },
    // navbar: {
    //   icon: 'assets:navbar-icon'
    // }
};
