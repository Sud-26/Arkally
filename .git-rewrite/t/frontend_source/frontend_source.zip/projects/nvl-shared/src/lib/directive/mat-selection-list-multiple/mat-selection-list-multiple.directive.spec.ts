import { MatSelectionListMultipleDirective } from './mat-selection-list-multiple.directive';

describe('MatSelectionListMultipleDirective', () => {
  it('should create an instance', () => {
    const directive = new MatSelectionListMultipleDirective();
    expect(directive).toBeTruthy();
  });
});
