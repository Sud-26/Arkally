export interface AvatarConfig {
    icon: string;
    class: string;
    background: string;
}