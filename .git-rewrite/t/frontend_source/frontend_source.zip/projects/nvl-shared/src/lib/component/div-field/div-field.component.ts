import { Component, OnInit } from '@angular/core';

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'div-field',
  templateUrl: './div-field.component.html',
  styleUrls: ['./div-field.component.scss']
})
export class DivFieldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
