import { MqIfDirective } from './mq-if.directive';

describe('MqIfDirective', () => {
  it('should create an instance', () => {
    const directive = new MqIfDirective();
    expect(directive).toBeTruthy();
  });
});
