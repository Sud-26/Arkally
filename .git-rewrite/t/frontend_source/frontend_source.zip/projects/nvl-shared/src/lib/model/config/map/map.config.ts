export interface MapConfig {
    
    
}