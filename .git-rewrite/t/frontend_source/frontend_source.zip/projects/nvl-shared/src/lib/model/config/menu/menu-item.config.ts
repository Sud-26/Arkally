export class MenuItem{
    id: number;
    label: string;
    route: string;
    icon: string;
    hidden?: boolean;
    scope?: string;
}