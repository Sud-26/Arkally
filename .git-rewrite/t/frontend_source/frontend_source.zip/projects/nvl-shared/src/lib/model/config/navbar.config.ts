export interface NavbarConfig {
  icon: string;
}
